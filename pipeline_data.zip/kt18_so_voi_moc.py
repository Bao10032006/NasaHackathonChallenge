"""KIỂM TOÁN 18 (bản 1.6): mô hình mặc định hơn các mốc so sánh (baseline) bao nhiêu?

Năm cách quy đổi Aqua -> tương đương S-NPP, từ đơn giản đến mô hình mặc định:
  ti_so_toan_cuc   một tỉ số cho cả nước
  ti_so_theo_thang 12 tỉ số theo tháng
  ti_so_theo_o     một tỉ số cho mỗi ô (phương án lùi)
  hurdle           hurdle ô x mùa
  lai              trung bình của ti_so_theo_o và hurdle (mặc định)
Mỗi cách được học trên 5 năm và kiểm trên 5 năm còn lại, theo MỌI cách chia 2012-2021 (252 lượt), cùng nguồn Aqua mặc định.

Cách chạy: python kt18_so_voi_moc.py <thư mục hoalich_data_v1> <thư mục raw_firms> <thư mục tạm>
"""
import os
import sys
if len(sys.argv) < 4:
    print("Cách chạy: python %s <thư mục hoalich_data_v1> <thư mục raw_firms> <thư mục tạm>" % os.path.basename(sys.argv[0]))
    sys.exit(2)
P, RAW, WORK = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(WORK, exist_ok=True)
sys.path.insert(0, P)
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import contextlib
import io
import itertools

import numpy as np
import pandas as pd
import hoalich_pipeline as hp

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 60); pd.set_option("display.max_rows", 200)
ARGS = hp.default_args(RAW, os.path.join(WORK, "kt18_out"))
with contextlib.redirect_stdout(io.StringIO()):
    ctx = hp.prepare_args(ARGS)
ax, Mm, expo = ctx["ax"], ctx["Mm"], ctx["expo"]
iy, ix, ny, nx, reg_i = ctx["iy"], ctx["ix"], ctx["ny"], ctx["nx"], ctx["reg_i"]
mon, yrs = ax["m_month"], ax["m_year"]
ym = yrs * 100 + mon
A = hp.model_inputs(ctx, ARGS)[0]
V = Mm["SNPP"]
in_cal = (ym >= hp.CAL_START[0] * 100 + hp.CAL_START[1]) & (ym <= hp.CAL_END[0] * 100 + hp.CAL_END[1])
Wcal = (in_cal[:, None] & (expo["Aqua"] >= 0.999) & (expo["SNPP"] >= 0.999)).astype(float)
grid = (iy, ix, ny, nx, 2)
REG = list(hp.REGION_NAMES)
YEARS = list(range(hp.CAL_START[0], hp.CAL_END[0] + 1))
MODELS = ["ti_so_toan_cuc", "ti_so_theo_thang", "ti_so_theo_o", "hurdle", "lai"]
CONTIG = ((2012, 2013, 2014, 2015, 2016), (2017, 2018, 2019, 2020, 2021))


def predict_all(tr_t, te_t):
    W = Wcal * tr_t[:, None]
    par = hp.fit_hurdle(A, V, W, mon, hp.SEASONS[2], grid, floor="clim")
    pc = hp.fit_cell_ratio(A, V, W, grid)
    ph = hp.predict_hurdle(par, A[te_t], None, mon[te_t])
    pr = pc["r_c"][None, :] * A[te_t]
    return {"ti_so_toan_cuc": hp.fit_global(A, V, W)["r"] * A[te_t],
            "ti_so_theo_thang": hp.fit_monthly(A, V, W, mon)["r"][mon[te_t] - 1][:, None] * A[te_t],
            "ti_so_theo_o": pr, "hurdle": ph, "lai": 0.5 * (ph + pr)}


rows = []
for tr in itertools.combinations(YEARS, 5):
    tr_t = np.isin(yrs, tr).astype(float)
    te_t = (~np.isin(yrs, tr)) & in_cal & (Wcal.sum(1) > 0)
    w = Wcal[te_t]
    o = V[te_t] * w
    oc = o.sum(0)
    for name, Pr in predict_all(tr_t, te_t).items():
        p = Pr * w
        pcell = p.sum(0)
        r = {"mo_hinh": name, "hoc": "-".join(map(str, tr)), "lien_khoi": tr in CONTIG,
             "ToanQuoc": 100 * (pcell.sum() / oc.sum() - 1), "rmse_o_thang": float(np.sqrt(((p - o)[w > 0] ** 2).mean()))}
        for i, rn in enumerate(REG):
            m = reg_i == i
            r[rn] = 100 * (pcell[m].sum() / oc[m].sum() - 1)
        rows.append(r)
df = pd.DataFrame(rows)
df["XauNhat"] = df[REG].abs().max(axis=1)
df.to_csv(os.path.join(WORK, "kt18_so_voi_moc.csv"), index=False)

print("### 1. Cách chia liền khối (phép kiểm hai chiều của pipeline): lệch % và RMSE cấp ô-tháng")
c = df[df.lien_khoi].copy()
print(c[["mo_hinh", "hoc", "ToanQuoc"] + REG + ["XauNhat", "rmse_o_thang"]].round(2).to_string(index=False))

print("\n### 2. Qua 252 lượt học 5 năm / kiểm 5 năm: |lệch| (%) trung vị, phân vị 90, lớn nhất; RMSE cấp ô-tháng trung bình")
out = []
for name in MODELS:
    d = df[df.mo_hinh == name]
    r = {"mo_hinh": name}
    for u in ["ToanQuoc"] + REG + ["XauNhat"]:
        a = d[u].abs()
        r[u + "_tv"], r[u + "_p90"] = a.median(), a.quantile(0.9)
    r["XauNhat_max"] = d["XauNhat"].max()
    r["rmse_o_thang"] = d["rmse_o_thang"].mean()
    out.append(r)
res = pd.DataFrame(out)
print(res.round(2).to_string(index=False))
res.round(3).to_csv(os.path.join(WORK, "kt18_tom_tat.csv"), index=False)

print("\n### 3. Trên cùng từng lượt chia: tỉ lệ lượt (%) mà mô hình 'lai' tốt hơn từng mốc")
base = df[df.mo_hinh == "lai"].set_index("hoc")
t = []
for name in MODELS[:-1]:
    o_ = df[df.mo_hinh == name].set_index("hoc").loc[base.index]
    t.append({"so_voi": name, "ToanQuoc": 100 * np.mean(base.ToanQuoc.abs().values < o_.ToanQuoc.abs().values),
              "XauNhat": 100 * np.mean(base.XauNhat.values < o_.XauNhat.values),
              "rmse_o_thang": 100 * np.mean(base.rmse_o_thang.values < o_.rmse_o_thang.values)})
print(pd.DataFrame(t).round(1).to_string(index=False))
